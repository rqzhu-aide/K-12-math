@echo off
setlocal
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0runtime\tutor_companion.py" %*
goto done
:use_python
python "%~dp0runtime\tutor_companion.py" %*
:done
if not errorlevel 1 exit /b 0
echo.
echo The tutor companion could not start. Read the error above and the included README.
pause
exit /b 1
