#!/bin/sh
set -eu
companion_directory=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Install Python 3 in your shared user or system installation, then try again.' >&2
    exit 1
fi
exec python3 "$companion_directory/runtime/tutor_companion.py" "$@"
