"""Serve only a paired website's ChatGPT tutor calls on the student's device.

This is a separate loopback service, not the Math Practice desktop runtime.
Account storage, OAuth, model discovery and Responses transport remain owned by
ChatGPTPlan. No provider token, arbitrary destination or local file is exposed.
"""
import argparse
import base64
import binascii
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import re
import secrets
import sys
from urllib.parse import urlsplit

from chatgpt_plan import ChatGPTPlan, PlanError
from student_assessment import AssessmentError

APPLICATION = 'math-practice-tutor-companion'
VERSION = 1
PORT = 8879
SITE_ORIGIN = 'https://math-practice.ailleo.net'
MAX_BODY_BYTES = 12_000_000
ROUTES = {'/api/companion/status': 'GET', **{
    '/api/companion/chatgpt/' + action: 'POST'
    for action in ('login', 'cancel', 'models', 'test', 'logout', 'infer')}}
IMAGE = re.compile(r'data:image/(?:png|jpeg|webp|gif);base64,([A-Za-z0-9+/]*={0,2})\Z')


def local_test_origin(value):
    """Allow explicit development origins without widening production trust."""
    try:
        parts = urlsplit(value)
        if (parts.scheme == 'http' and parts.hostname in ('127.0.0.1', 'localhost')
                and parts.port is not None and 1 <= parts.port <= 65535
                and not parts.username and not parts.password and not parts.path
                and not parts.query and not parts.fragment
                and parts.netloc == f'{parts.hostname}:{parts.port}'):
            return value
    except ValueError:
        pass
    raise argparse.ArgumentTypeError('Use an exact local test origin such as http://127.0.0.1:8877.')


def _fields(body, allowed):
    if set(body) - set(allowed):
        raise PlanError('This request contains unsupported fields. Refresh Math Practice and try again.', 400)


def _selection(value):
    if not isinstance(value, dict):
        raise PlanError('Choose a ChatGPT tutor model.', 400)
    _fields(value, ('model', 'effort'))
    model, effort = value.get('model'), value.get('effort')
    if not isinstance(model, str) or not model.strip() or len(model) > 200 or any(ord(c) < 32 for c in model):
        raise PlanError('Choose a ChatGPT tutor model.', 400)
    if effort is not None and (not isinstance(effort, str) or not re.fullmatch(r'[a-z0-9_-]{1,32}', effort)):
        raise PlanError('Choose a supported reasoning effort or leave it unset.', 400)
    return {'model': model, **({'effort': effort} if effort else {})}


def _inference(body):
    _fields(body, ('selection', 'prompt', 'instructions', 'schema', 'images'))
    selection = _selection(body.get('selection'))
    for field in ('prompt', 'instructions'):
        if not isinstance(body.get(field), str) or not body[field].strip() or len(body[field]) > 300_000:
            raise PlanError('The tutor request is missing text or is too long. Try a shorter explanation.', 400)
    schema = body.get('schema')
    if schema is not None and (not isinstance(schema, dict) or len(json.dumps(schema)) > 100_000):
        raise PlanError('The tutor response format is invalid. Refresh Math Practice and try again.', 400)
    images = body.get('images', [])
    if not isinstance(images, list) or len(images) > 16:
        raise PlanError('Send at most sixteen inline question images.', 400)
    for image in images:
        match = IMAGE.fullmatch(image) if isinstance(image, str) else None
        if not match:
            raise PlanError('Question images must be inline PNG, JPEG, WebP or GIF data.', 400)
        try:
            if not base64.b64decode(match[1], validate=True):
                raise ValueError()
        except (ValueError, binascii.Error):
            raise PlanError('A question image could not be read. Reload the question and try again.', 400) from None
    return selection, body['prompt'], body['instructions'], schema, images


class CompanionServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, *, pairing_key, plan=None, port=PORT, test_origins=()):
        if not isinstance(pairing_key, str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}', pairing_key):
            raise ValueError('Use a locally generated pairing key with at least 32 characters.')
        self.pairing_key = pairing_key
        self.plan = plan if plan is not None else ChatGPTPlan()
        self.trusted_origins = frozenset((SITE_ORIGIN, *(local_test_origin(value) for value in test_origins)))
        # The address cannot be overridden by a flag, environment or website.
        super().__init__(('127.0.0.1', port), CompanionHandler)

    def status(self):
        return {'application': APPLICATION, 'version': VERSION, 'paired': True, 'chatgpt': self.plan.status()}


class CompanionHandler(BaseHTTPRequestHandler):
    server_version = 'MathPracticeTutorCompanion/1'

    def setup(self):
        super().setup()
        self.connection.settimeout(15)
        self.cors_origin = None

    def log_message(self, *args):
        # Request paths, browser data and credentials never enter a log.
        pass

    def _respond(self, status, value=None, *, preflight=False, private_network=False):
        raw = b'' if value is None else json.dumps(value, ensure_ascii=True).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
        self.send_header('Connection', 'close')
        self.send_header('Vary', 'Origin, Access-Control-Request-Method, Access-Control-Request-Headers, Access-Control-Request-Private-Network')
        if self.cors_origin:
            self.send_header('Access-Control-Allow-Origin', self.cors_origin)
            if preflight:
                self.send_header('Access-Control-Allow-Methods', ROUTES[self.path])
                self.send_header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
                self.send_header('Access-Control-Max-Age', '300')
                if private_network:
                    self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.end_headers()
        self.close_connection = True
        if raw:
            self.wfile.write(raw)

    def _guard(self, *, preflight=False):
        expected_host = f'127.0.0.1:{self.server.server_port}'
        if (self.client_address[0] != '127.0.0.1' or self.headers.get_all('Host') != [expected_host]):
            raise PlanError('Use the companion address shown in Math Practice Settings.', 403)
        origins = self.headers.get_all('Origin')
        if not origins or len(origins) != 1 or origins[0] not in self.server.trusted_origins:
            raise PlanError('This website is not allowed to use the tutor companion.', 403)
        self.cors_origin = origins[0]
        if self.path not in ROUTES:
            raise PlanError('This tutor companion action is unavailable. Refresh Math Practice.', 404)
        method = self.headers.get('Access-Control-Request-Method') if preflight else self.command
        if method != ROUTES[self.path]:
            raise PlanError('This tutor companion action uses a different request method.', 405)
        if not preflight:
            values = self.headers.get_all('Authorization') or []
            expected = 'Bearer ' + self.server.pairing_key
            if len(values) != 1 or not hmac.compare_digest(values[0].encode('utf-8'), expected.encode('ascii')):
                raise PlanError('Enter the current pairing key from the tutor companion window, then connect again.', 401)

    def do_OPTIONS(self):
        try:
            self._guard(preflight=True)
            requested = {value.strip().lower() for value in self.headers.get('Access-Control-Request-Headers', '').split(',') if value.strip()}
            if 'authorization' not in requested or requested - {'authorization', 'content-type'}:
                raise PlanError('This request uses unsupported tutor companion headers.', 403)
            private = self.headers.get('Access-Control-Request-Private-Network')
            if private is not None and private != 'true':
                raise PlanError('This local-network request is invalid.', 400)
            # Browser preflights cannot include the pairing key. This response
            # permits a trusted origin to try; every actual request checks it.
            self._respond(204, preflight=True, private_network=private == 'true')
        except PlanError as error:
            self._respond(error.status, {'error': str(error)})

    def _body(self):
        if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length') or []) != 1:
            raise PlanError('Send a JSON tutor request with its content length.', 400)
        try:
            length = int(self.headers['Content-Length'])
        except (TypeError, ValueError):
            raise PlanError('The tutor request length is invalid.', 400) from None
        if not 0 < length <= MAX_BODY_BYTES:
            raise PlanError('The tutor request is too large. Try fewer images or a shorter explanation.', 413)
        # Consume a bounded body's bytes before rejecting its media type. Some
        # operating systems reset a socket closed with unread request data.
        raw = self.rfile.read(length)
        if self.headers.get('Content-Type', '').partition(';')[0].strip().lower() != 'application/json':
            raise PlanError('Send the tutor request as JSON.', 415)
        try:
            if len(raw) != length:
                raise ValueError()
            value = json.loads(raw)
        except (ValueError, UnicodeError, RecursionError):
            raise PlanError('The tutor request could not be read. Refresh Math Practice and try again.', 400) from None
        if not isinstance(value, dict):
            raise PlanError('Send a JSON object for this tutor action.', 400)
        return value

    def _action(self):
        if self.command == 'GET':
            return self.server.status()
        body = self._body()
        action = self.path.rsplit('/', 1)[-1]
        plan = self.server.plan
        if action == 'infer':
            return {'reply': plan.infer(*_inference(body))}
        if action == 'test':
            from practice_tutor import test_tutor_connection
            selection = {**_selection(body), 'provider': 'chatgpt'}
            return {'ok': True, **test_tutor_connection(selection, plan)}
        if action == 'login':
            _fields(body, ('clientId', 'newAccount'))
            client, new = body.get('clientId'), body.get('newAccount', False)
            if (not isinstance(new, bool) or (client is not None and
                    (not isinstance(client, str) or not re.fullmatch(r'oaiapp_[A-Za-z0-9_-]{1,200}', client)))
                    or (new and client is not None)):
                raise PlanError('Choose a saved ChatGPT account or use another account.', 400)
            plan.start_login(client_id=client, new_account=new)
        else:
            _fields(body, ())
            {'cancel': plan.cancel_login, 'models': plan.refresh_models, 'logout': plan.sign_out}[action]()
        return self.server.status()

    def _serve(self):
        try:
            self._guard()
            self._respond(200, self._action())
        except AssessmentError as error:
            # Safe public messages only. PlanError.body may contain provider
            # diagnostics or submitted text and must never be serialized.
            self._respond(error.status, {'error': str(error)})
        except (OSError, TimeoutError):
            try:
                self._respond(503, {'error': 'The tutor connection was interrupted. Keep the companion running and try again.'})
            except OSError:
                pass
        except Exception:
            self._respond(500, {'error': 'The tutor companion could not finish this action. Restart it and reconnect in Settings.'})

    do_GET = _serve
    do_POST = _serve


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--test-origin', action='append', type=local_test_origin, default=[],
                        help='Also trust one exact local HTTP origin for development.')
    args = parser.parse_args(argv)
    pairing_key = secrets.token_urlsafe(32)
    try:
        server = CompanionServer(pairing_key=pairing_key, test_origins=args.test_origin)
    except OSError:
        print('The tutor companion could not open its local port. Close another tutor companion window and try again.', file=sys.stderr)
        return 1
    print('Math Practice tutor companion is running on this device.')
    print('Keep this window open while using your ChatGPT tutor.')
    print('Open Math Practice Settings and enter this pairing key:')
    print(pairing_key, flush=True)
    print('If your browser asks to access the local network, allow it for Math Practice.')
    print('This key changes when you restart the companion. Press Ctrl+C to stop.', flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        server.plan.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
